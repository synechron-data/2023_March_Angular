import { Component } from '@angular/core';
import { BehaviorSubject, concat, delay, EMPTY, filter, map, Observable, of, reduce, ReplaySubject, startWith, Subject, Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html'
})
export class RootComponent {
  obSub?: Subscription;

  constructor() {
    // this.getPromise();
    // this.getObservable();

    // --------------------------------------------------
    // this.getPromise().then(data => {
    //   console.log(`Promise Output - ${data}`);
    // }).catch(err => {
    //   console.error(`Promise Error - ${err}`);
    // });

    // this.obSub = this.getObservable().subscribe({
    //   next: data => {
    //     console.log(`Observable Output - ${data}`);
    //   },
    //   error: err => {
    //     console.error(`Observable Error - ${err}`);
    //   }
    // });

    // setTimeout(()=>{
    //   this.obSub?.unsubscribe();
    // }, 9000);

    // --------------------------------------------- Observables are single-cast
    // var observable = this.getObservable();

    // observable.subscribe({
    //   next: data => {
    //     console.log(`Subscriber 1, Output - ${data}`);
    //   }
    // });

    // observable.subscribe({
    //   next: data => {
    //     console.log(`Subscriber 2, Output - ${data}`);
    //   }
    // });

    // // --------------------------------------------- Subjects are multi-cast
    // var subject = this.getSubject();

    // subject.subscribe({
    //   next: data => {
    //     console.log(`Subscriber 1, Output - ${data}`);
    //   }
    // });

    // subject.subscribe({
    //   next: data => {
    //     console.log(`Subscriber 2, Output - ${data}`);
    //   }
    // });

    // subject.next(Math.random());
    // subject.complete();
    // subject.error("Some Error");

    // --------------------------------------------- Subjects are multi-cast
    // var observable = this.getSubjectAsObservable();

    // observable.subscribe({
    //   next: data => {
    //     console.log(`Subscriber 1, Output - ${data}`);
    //   }
    // });

    // observable.subscribe({
    //   next: data => {
    //     console.log(`Subscriber 2, Output - ${data}`);
    //   }
    // });

    // --------------------------------------------- Subject Types
    // var subject = this.getSubjectA();
    // var subject = this.getSubjectB();
    // var subject = this.getSubjectC();

    // var s1 = subject.subscribe({
    //   next: data => {
    //     console.log(`Subscriber 1, Output - ${data}`);
    //   }
    // });

    // var s2: Subscription;

    // setTimeout(() => {
    //   console.log("\nAfter 6 secs, S2 subscribed: ")

    //   s2 = subject.subscribe({
    //     next: data => {
    //       console.log(`Subscriber 2, Output - ${data}`);
    //     }
    //   });
    // }, 6100)

    // setTimeout(() => {
    //   s1.unsubscribe();
    //   s2.unsubscribe();
    //   console.log("\nAfter 11 secs, unsubscribed from all subscriptions");
    // }, 11000);

    // --------------------------------------------- Observable Operators
    // let numObservable = of(10, 20, 31, 43, 50, 67, 70, 80, 89, 90);

    // // numObservable.subscribe({
    // //   next: n => { console.log(n); }
    // // });

    // // numObservable.pipe(filter(n => n % 2 === 0)).subscribe({
    // //   next: n => { console.log(n); }
    // // });

    // // numObservable.pipe(map(n => n * 10)).subscribe({
    // //   next: n => { console.log(n); }
    // // });

    // // numObservable.pipe(reduce((acc, n) => acc + n)).subscribe({
    // //   next: n => { console.log(n); }
    // // });

    // numObservable.pipe(
    //   filter(n => n % 2 === 0),
    //   map(n => n * 10),
    //   reduce((acc, n) => acc + n),
    //   delay(4000)
    // ).subscribe({
    //   next: n => { console.log(n); }
    // });

    // --------------------------------

    // let ob1 = of(10, 20, 30);
    // let ob2 = of(40, 50, 60);

    // concat(ob1, ob2).subscribe(n => { console.log(n); });

    // concat(
    //   this.delayedMessage("Get Ready!"),
    //   this.delayedMessage(3),
    //   this.delayedMessage(2),
    //   this.delayedMessage(1),
    //   this.delayedMessage("Go Now!")
    // ).subscribe(m => { console.log(m); });
  }

  delayedMessage(message: any, delayTime = 1000) {
    return EMPTY.pipe(startWith(message), delay(delayTime));
  }

  getSubjectC(): ReplaySubject<number> {
    let s = new ReplaySubject<number>();
    // let s = new ReplaySubject<number>(2);

    let count = 1;

    setInterval(function () {
      s.next(count++);
    }, 2000);

    return s;
  }

  getSubjectB(): BehaviorSubject<number> {
    let s = new BehaviorSubject<number>(0);       // Initial Data
    let count = 1;

    setInterval(function () {
      s.next(count++);
    }, 2000);

    return s;
  }

  getSubjectA(): Subject<number> {
    let s = new Subject<number>();
    let count = 1;

    setInterval(function () {
      s.next(count++);
    }, 2000);

    return s;
  }

  getSubjectAsObservable(): Observable<number> {
    let s = new Subject<number>();

    setInterval(function () {
      s.next(Math.random());
    }, 4000);

    return s.asObservable();
  }

  getSubject(): Subject<number> {
    let s = new Subject<number>();

    setInterval(function () {
      s.next(Math.random());
    }, 4000);

    return s;
  }

  getObservable(): Observable<number> {
    return new Observable((ob) => {
      // Any Async Code
      setInterval(function () {
        // console.log("Observable - Set Interval Executed...");
        ob.next(Math.random());
      }, 4000);
    });
  }

  getPromise(): Promise<number> {
    return new Promise((resolve, reject) => {
      // Any Async Code
      setInterval(function () {
        // console.log("Promise - Set Interval Executed...");
        resolve(Math.random());
      }, 4000);
    });
  }
}
