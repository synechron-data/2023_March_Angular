import { Component } from '@angular/core';

@Component({
  selector: 'app-comp-one',
  template: `
    <h1 class="text-success">
      Hello from Component One
    </h1>
  `,
  styles: [
  ]
})
export class CompOneComponent {

}
