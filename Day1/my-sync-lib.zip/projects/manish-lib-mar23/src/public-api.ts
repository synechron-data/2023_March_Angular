/*
 * Public API Surface of manish-lib-mar23
 */

export * from './lib/manish-lib-mar23.service';
export * from './lib/manish-lib-mar23.component';
export * from './lib/manish-lib-mar23.module';
