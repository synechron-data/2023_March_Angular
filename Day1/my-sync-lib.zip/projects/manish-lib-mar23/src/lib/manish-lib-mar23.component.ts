import { Component } from '@angular/core';

@Component({
  selector: 'lib-manish-lib-mar23',
  template: `
    <h3>
      manish-lib-mar23 works!
    </h3>
  `,
  styles: [
  ]
})
export class ManishLibMar23Component {

}
