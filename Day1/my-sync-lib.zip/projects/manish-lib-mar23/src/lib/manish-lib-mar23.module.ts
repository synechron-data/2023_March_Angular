import { NgModule } from '@angular/core';
import { ManishLibMar23Component } from './manish-lib-mar23.component';



@NgModule({
  declarations: [
    ManishLibMar23Component
  ],
  imports: [
  ],
  exports: [
    ManishLibMar23Component
  ]
})
export class ManishLibMar23Module { }
