import { TestBed } from '@angular/core/testing';

import { ManishLibMar23Service } from './manish-lib-mar23.service';

describe('ManishLibMar23Service', () => {
  let service: ManishLibMar23Service;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ManishLibMar23Service);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
