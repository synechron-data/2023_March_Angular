import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManishLibMar23Component } from './manish-lib-mar23.component';

describe('ManishLibMar23Component', () => {
  let component: ManishLibMar23Component;
  let fixture: ComponentFixture<ManishLibMar23Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManishLibMar23Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ManishLibMar23Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
