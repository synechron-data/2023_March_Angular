import { Component } from '@angular/core';

@Component({
  selector: 'app-s-comp',
  template: `
    <h3 class="text-danger">I am the Shared Component from Shared Module</h3>
  `,
  styles: [
  ]
})
export class SCompComponent {

}
