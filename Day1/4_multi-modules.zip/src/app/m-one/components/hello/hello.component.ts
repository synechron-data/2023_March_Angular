import { Component } from '@angular/core';

@Component({
  selector: 'app-hello',
  template: `
    <h2 class="text-warning">
      Hello from Module One
    </h2>
  `,
  styles: [
  ]
})
export class HelloComponent {

}
