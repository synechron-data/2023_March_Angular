import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Post } from 'src/app/models/post.model';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
  providers: [UserService]
})
export class UserComponent implements OnInit, OnDestroy {
  users?: Array<any>;
  flag: boolean;
  message?: string;
  get_sub?: Subscription;
  get_posts_sub?: Subscription;

  selectedUserId: string;
  selectedUserDetails?: any;

  posts?: Array<Post>;

  constructor(private userService: UserService) {
    this.flag = false;
    this.selectedUserId = "";
  }
  
  ngOnInit(): void {
    this.get_sub = this.userService.getAllUsers().subscribe({
      next: resData => {
        this.users = resData;
        this.message = "";
        this.flag = true;
      }, error: (err: string) => {
        this.message = err;
      }
    });
  }

  getDetails(userId: string) {
    this.get_posts_sub = this.userService.getUserPosts(userId).subscribe({
      next: resData => {
        this.posts = [...resData];
      }, error: (err: string) => {
        this.message = err;
      }
    });
  }

  ngOnDestroy(): void {
    this.get_sub?.unsubscribe();
    this.get_posts_sub?.unsubscribe();
  }
}
