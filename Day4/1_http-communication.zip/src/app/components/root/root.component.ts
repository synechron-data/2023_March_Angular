// import { HttpClient, HttpErrorResponse } from '@angular/common/http';
// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { Subscription } from 'rxjs';
// import { Post } from 'src/app/models/post.model';

// @Component({
//     selector: 'app-root',
//     templateUrl: './root.component.html',
//     styleUrls: ['./root.component.css']
// })
// export class RootComponent implements OnInit, OnDestroy {
//     url: string;
//     message: string;
//     posts?: Array<Post>;
//     get_sub?: Subscription;

//     constructor(private httpClient: HttpClient) {
//         this.url = "https://jsonplaceholder.typicode.com/posts";
//         this.message = "Loading Data, please wait...";
//     }

//     ngOnInit() {
//         this.get_sub = this.httpClient.get<Array<Post>>(this.url).subscribe({
//             next: resData => {
//                 this.posts = [...resData];
//                 this.message = "";
//             },
//             error: (err: HttpErrorResponse) => {
//                 this.message = err.message;
//             }
//         });
//     }

//     ngOnDestroy(): void {
//         this.get_sub?.unsubscribe();
//     }
// }

// // --------------------------------------------

// import { HttpErrorResponse } from '@angular/common/http';
// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { Subscription } from 'rxjs';
// import { Post } from 'src/app/models/post.model';
// import { PostService } from 'src/app/services/post.service';

// @Component({
//     selector: 'app-root',
//     templateUrl: './root.component.html',
//     styleUrls: ['./root.component.css'],
//     providers: [PostService]
// })
// export class RootComponent implements OnInit, OnDestroy {
//     message: string;
//     posts?: Array<Post>;
//     get_sub?: Subscription;

//     constructor(private postService: PostService) {
//         this.message = "Loading Data, please wait...";
//     }

//     ngOnInit() {
//         this.get_sub = this.postService.getAllPosts().subscribe({
//             next: resData => {
//                 this.posts = [...resData];
//                 this.message = "";
//             },
//             error: (err: HttpErrorResponse) => {
//                 this.message = err.message;
//             }
//         });
//     }

//     ngOnDestroy(): void {
//         this.get_sub?.unsubscribe();
//     }
// }

// --------------------------------------------

import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Post } from 'src/app/models/post.model';
import { PostService } from 'src/app/services/post.service';

@Component({
    selector: 'app-root',
    templateUrl: './root.component.html',
    styleUrls: ['./root.component.css'],
    providers: [PostService]
})
export class RootComponent implements OnInit, OnDestroy {
    message: string;
    posts?: Array<Post>;
    get_sub?: Subscription;
    del_sub?: Subscription;

    constructor(private postService: PostService) {
        this.message = "Loading Data, please wait...";
    }

    ngOnInit() {
        // this.get_sub = this.postService.getAllPosts().subscribe({
        //     next: resData => {
        //         this.posts = [...resData];
        //         this.message = "";
        //     },
        //     error: (err: string) => {
        //         this.message = err;
        //     }
        // });
    }

    deletePost(id: number, e: Event) {
        e.preventDefault();

        this.message = `Deleting a record with id: ${id}...`;

        this.del_sub = this.postService.deletePost(id).subscribe({
            next: () => {
                if (this.posts) {
                    this.posts = [...this.posts?.filter(p => p.id !== id)];
                    this.message = "Record Deleted...";
                    setTimeout(() => {
                        this.message = "";
                    }, 3000);
                }
            },
            error: (err: string) => {
                this.message = err;
            }
        });
    }

    ngOnDestroy(): void {
        this.get_sub?.unsubscribe();
        this.del_sub?.unsubscribe();
    }
}