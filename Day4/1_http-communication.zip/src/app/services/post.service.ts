import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { catchError, delay, Observable, retry, throwError } from "rxjs";
import { environment } from "src/environments/environment";
import { Post } from "../models/post.model";

@Injectable()
// @Injectable({ providedIn: "root" })
export class PostService {
    private url: string;

    constructor(private httpClient: HttpClient) {
        // this.url = "https://jsonplaceholder.typicode.com/posts";
        this.url = environment.postsUrl;
    }

    // getAllPosts() {
    //     return this.httpClient.get<Array<Post>>(this.url);
    // }

    getAllPosts() {
        return this.httpClient.get<Array<Post>>(this.url).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError('getAllPosts', []))
        );
    }

    deletePost(id: number) {
        const deleteUrl = `${this.url}/${id}`;

        return this.httpClient.delete(deleteUrl).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError('deletePost'))
        );
    }

    private _handleError<T>(operation = "operation", result?: T) {
        return (err: HttpErrorResponse): Observable<T> => {
            // Error Logging / Reporting
            console.log(`${operation} failed: ${err.message}`);
            switch (err.status) {
                case 403:
                    return throwError(() => err.error.message);
                case 500:
                    return throwError(() => err.statusText);
                default:
                    return throwError(() => "Connection Error, please try again later...");
            }
        }
    }
}