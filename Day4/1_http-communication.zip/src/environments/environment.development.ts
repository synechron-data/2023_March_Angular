export const environment = {
    production: false,
    postsUrl: 'https://jsonplaceholder.typicode.com/posts',
    usersUrl: 'https://jsonplaceholder.typicode.com/users'
};
