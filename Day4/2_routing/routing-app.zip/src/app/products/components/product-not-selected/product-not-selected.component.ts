import { Component } from '@angular/core';

@Component({
  selector: 'product-not-selected',
  templateUrl: './product-not-selected.component.html',
  styleUrls: ['./product-not-selected.component.css']
})
export class ProductNotSelectedComponent {

}
