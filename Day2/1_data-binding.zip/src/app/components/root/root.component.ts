import { Component, NgZone } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html'
})
export class RootComponent {
  message: string;
  flag: boolean;
  h: number;
  w: number;
  greetings: string;
  name!: string;
  count: number;

  constructor(private ngZone: NgZone) {
    this.message = "Hello World!";
    this.flag = false;
    this.h = 300;
    this.w = 300;
    this.greetings = "Hello";
    this.count = 0;
  }

  doChange() {
    this.message = new Date().toTimeString();
  }

  anchorClick1() {
    this.message = new Date().toTimeString();
  }

  anchorClick2(e: Event) {
    this.message = new Date().toTimeString();
    e.preventDefault();
  }

  doUpdate(n: string) {
    this.greetings = `Hello, ${n}`;
    console.log("Event Fired");
  }

  incrementCount(cb: () => void) {
    this.count += 1;
    if (this.count < 50) {
      window.setTimeout(() => {
        this.incrementCount(cb);
      }, 100);
    } else {
      cb();
    }
  }

  inZone() {
    this.count = 0;
    this.message = "Started...";
    this.incrementCount(() => {
      this.message = "Completed...";
    });
  }

  outOfZone() {
    this.count = 0;
    this.message = "Started...";
    this.ngZone.runOutsideAngular(() => {
      this.incrementCount(() => {
        this.ngZone.run(() => {
          this.message = "Completed...";
        });
      });
    })
  }
}
