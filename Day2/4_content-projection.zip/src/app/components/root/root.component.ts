import { Component, NgZone } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html'
})
export class RootComponent {
  onNewValue(val: any) {
    console.log(val);
  }
}
